//
//  Pongish_HackwichApp.swift
//  Pongish Hackwich
//
//  Created by Breshears, Rob - TMH on 1/29/24.
//

import SwiftUI

@main
struct Pongish_HackwichApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
